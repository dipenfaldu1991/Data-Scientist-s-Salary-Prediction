#!/usr/bin/env python
# coding: utf-8

# In[ ]:


# Importing essential libraries
import numpy as np
import pandas as pd


# In[ ]:


# Loading the dataset
df = pd.read_csv("glassdoor_jobs.csv")


# # **Exploring the dataset**

# In[4]:


# Returns number of rows and columns of the dataset
df.shape


# In[5]:


# Returns an object with all of the column headers 
df.columns


# In[6]:


# Returns different datatypes for each columns (float, int, string, bool, etc.)
df.dtypes


# In[7]:


# Returns the first x number of rows when head(x). Without a number it returns 5
df.head()


# In[8]:


# Returns the last x number of rows when tail(x). Without a number it returns 5
df.tail()


# In[9]:


# Returns basic information on all columns
df.info()


# In[10]:


# Returns basic statistics on numeric columns
df.describe().T


# In[11]:


# Returns true for a column having null values, else false
df.isnull().any()


# # **Data Cleaning**

# In[12]:


# Removing the 'Unnamed' column
df.drop(labels='Unnamed: 0', axis='columns', inplace=True)
df.columns


# In[13]:


# Removing the rows having '-1' as Salary Estimate value
print("Before: ",df.shape)
df = df[df['Salary Estimate'] != "-1"]
print("After: ", df.shape)
 

# In[14]:


# Removing the text value from 'Salary Estimate' column
salary = df['Salary Estimate'].apply(lambda x: x.split("(")[0])
salary


# In[15]:


# Removing '$' and 'K' from 'Salary Estimate' column
salary = salary.apply(lambda x: x.replace("$","").replace("K",""))
salary


# In[16]:


# Finding any inconsistencies in the salary
print("Length of Salary: ",len(salary.unique()))
salary.unique()[380:]


# In[ ]:


# Creating column for 'Per Hour'
df['salary_per_hour'] = salary.apply(lambda x: 1 if "per hour" in x.lower() else 0)


# In[18]:


df['salary_per_hour'].value_counts()


# In[ ]:


# Creating column for 'Employee Provided Salary'
df['emp_provided_salary'] = salary.apply(lambda x: 1 if "employer provided salary" in x.lower() else 0)


# In[20]:


df['emp_provided_salary'].value_counts()


# In[21]:


# Removing 'Per Hour' and 'Employer Provided Salary' from 'Salary Estimate' column
salary = salary.apply(lambda x: x.lower().replace("per hour", "").replace("employer provided salary:", "").replace(" ",""))
salary.unique()[380:]


# In[22]:


# Creating column for min_salary
df["min_salary"] = salary.apply(lambda x: int(x.split("-")[0]))
df["min_salary"].tail()


# In[23]:


# Creating column for max_salary
df["max_salary"] = salary.apply(lambda x: int(x.split("-")[1]))
df["max_salary"].tail()


# In[ ]:


# Creating column for average_salary
df["average_salary"] = (df["min_salary"]+df["max_salary"])/2


# In[ ]:


# Converting the hourly salaries to annual salaries
df['min_salary'] = df.apply(lambda x: x['min_salary']*2 if x['salary_per_hour'] == 1 else x['min_salary'], axis=1)


# In[ ]:


df['max_salary'] = df.apply(lambda x: x['max_salary']*2 if x['salary_per_hour'] == 1 else x['max_salary'], axis=1)


# In[27]:

 
df[df['salary_per_hour'] == 1][['salary_per_hour','min_salary','max_salary']]


# In[28]:


# Removing numbers from 'Company Name' column
df["Company Name"] = df['Company Name'].apply(lambda x: x.split("\n")[0])
df["Company Name"].head(10)


# In[29]:


# Creating a column 'job_state'
df["job_state"] = df["Location"].apply(lambda x: x.split(',')[1])
df["job_state"].head()


# In[30]:


df['job_state'].unique()


# In[31]:


# Fixing Los Angeles to CA
df['job_state'] = df['job_state'].apply(lambda x: x.strip() if x.strip().lower() != 'los angeles' else 'CA')
df['job_state'].value_counts()[:5]


# In[32]:


df['job_state'].unique()


# In[33]:


# Calculating age of the companies
df["company_age"] = df['Founded'].apply(lambda x: x if x<1 else 2020-x)
df["company_age"].head()


# In[ ]:


# Cleaning the 'Job Description' column
df["python_job"] = df['Job Description'].apply(lambda x: 1 if 'python' in x.lower() else 0)
df["r_job"] = df['Job Description'].apply(lambda x: 1 if 'r studio' in x.lower() else 0)
df["spark_job"] = df['Job Description'].apply(lambda x: 1 if 'spark' in x.lower() else 0)
df["aws_job"] = df['Job Description'].apply(lambda x: 1 if 'aws' in x.lower() else 0)
df["excel_job"] = df['Job Description'].apply(lambda x: 1 if 'excel' in x.lower() else 0)


# In[35]:


# Python Jobs
df.python_job.value_counts()


# In[36]:


# R Studio Jobs
df.r_job.value_counts()


# In[37]:


# Spark Jobs
df.spark_job.value_counts()


# In[38]:


# AWS Jobs
df.aws_job.value_counts()


# In[39]:


# Excel Jobs
df.excel_job.value_counts()


# In[40]:


# Dataset till now
df.head()
 

# In[ ]:


# Cleaning the 'Job Title' column
def title_simplifier(title):
    if 'data scientist' in title.lower():
        return 'data scientist'
    elif 'data engineer' in title.lower():
        return 'data engineer'
    elif 'analyst' in title.lower():
        return 'analyst'
    elif 'machine learning' in title.lower():
        return 'mle'
    elif 'manager' in title.lower():
        return 'manager'
    elif 'director' in title.lower():
        return 'director'
    else:
        return 'na'

df['job_title_simplified'] = df['Job Title'].apply(title_simplifier)


# In[42]:


df['job_title_simplified'].value_counts()


# In[ ]:


def seniority(title):
    if 'sr' in title.lower() or 'senior' in title.lower() or 'sr' in title.lower() or 'lead' in title.lower() or 'principal' in title.lower():
            return 'senior'
    elif 'jr' in title.lower() or 'jr.' in title.lower():
        return 'jr'
    else:
        return 'na'

df['job_seniority'] = df['Job Title'].apply(seniority)


# In[44]:


df['job_seniority'].value_counts()


# In[45]:


# Cleaning 'Competitors' column
df['Competitors'] = df['Competitors'].apply(lambda x: len(x.split(',')) if x != '-1' else 0)
df['Competitors']


# In[46]:


# Cleaning 'Type of Ownership' column
df['Type of ownership'].value_counts()


# In[ ]:


def ownership_simplifier(text):
    if 'private' in text.lower():
      return 'Private'
    elif 'public' in text.lower():
      return 'Public'
    elif ('-1' in text.lower()) or ('unknown' in text.lower()):
      return 'Other Organization'
    else:
      return text

df['Type of ownership'] = df['Type of ownership'].apply(ownership_simplifier)


# In[48]:


df['Type of ownership'].value_counts()


# In[49]:


# Cleaning 'Revenue' column
df['Revenue'].value_counts()
 

# In[ ]:


def revenue_simplifier(text):
  if '-1' in text.lower():
    return 'Unknown / Non-Applicable'
  else:
    return text

df['Revenue'] = df['Revenue'].apply(revenue_simplifier)


# In[51]:


df['Revenue'].value_counts()


# In[52]:


df['Size'].value_counts()


# In[ ]:


# Cleaning 'Size' column
def size_simplifier(text):
  if '-1' in text.lower():
    return 'Unknown'
  else:
    return text

df['Size'] = df['Size'].apply(size_simplifier)


# In[54]:


df['Size'].value_counts()


# In[55]:


# Dataset till now
df.head()


# # **Exploratory Data Analysis**

# In[56]:


# Importing essential libraries
import matplotlib.pyplot as plt
import seaborn as sns
get_ipython().run_line_magic('matplotlib', 'inline')


# In[57]:


df.describe().T


# In[58]:


df['Rating'].hist()
plt.xlabel('Ratings')
plt.ylabel('Count')
plt.title("Company Ratings Histogram")


# In[59]:


df['company_age'].hist()
plt.xlabel('Time (in Years)')
plt.ylabel('Count')
plt.title("Companies Age Histogram")


# In[60]:


df['average_salary'].hist()
plt.xlabel('Annual Salary (in $)')
plt.ylabel('Count')
plt.title("Average Salary Histogram")


# In[61]:


sns.boxplot(y='average_salary', data=df, orient='v', palette='Set1')


# In[62]:


sns.boxplot(y='company_age', data=df, orient='v', palette='Set1')


# In[63]:


sns.boxplot(y='Rating', data=df, orient='v', palette='Set1')


# In[64]:


# Finding Correlation between columns
df[['company_age','average_salary','Rating']].corr()


# In[65]:


# Plotting the correlation
cmap = sns.diverging_palette(220, 10, as_cmap=True)
sns.heatmap(df[['company_age','average_salary','Rating']].corr(), vmax=.3, center=0, cmap=cmap, square=True, linewidths=.5, cbar_kws={"shrink": .5})


# In[66]:


# Exploring categorical data
df.columns


# In[ ]:


df_categorical = df[['Company Name', 'Location', 'Headquarters', 'Size', 'Type of ownership', 'Industry', 'Sector', 'Revenue', 'job_title_simplified', 'job_seniority']]


# In[68]:


# Plotting the data for 'Location' and 'Headquarters' columns
for i in ['Location', 'Headquarters']:
    unique_categories = df_categorical[i].value_counts()[:20]
    print("Graph for {}\nTotal records = {}".format(i, len(unique_categories)))
    chart = sns.barplot(x=unique_categories.index, y=unique_categories)
    chart.set_xticklabels(chart.get_xticklabels(), rotation=90)
    plt.show()


# In[69]:


# Plotting the data for 'Company Name', 'Size', 'Type of ownership', 'Revenue' columns
for i in ['Company Name', 'Size', 'Type of ownership', 'Revenue']:
    unique_categories = df_categorical[i].value_counts()[:20]
    print("Graph for {}\nTotal records = {}".format(i, len(unique_categories)))
    chart = sns.barplot(x=unique_categories.index, y=unique_categories)
    chart.set_xticklabels(chart.get_xticklabels(), rotation=90)
    plt.show()


# In[70]:


# Plotting the data for 'Industry', 'Sector' columns
for i in ['Industry', 'Sector']:
    unique_categories = df_categorical[i].value_counts()[:20]
    print("Graph for {}\nTotal records = {}".format(i, len(unique_categories)))
    chart = sns.barplot(x=unique_categories.index, y=unique_categories)
    chart.set_xticklabels(chart.get_xticklabels(), rotation=90)
    plt.show()


# In[71]:


# Plotting the data for 'job_title_simplified', 'job_seniority' columns
for i in ['job_title_simplified', 'job_seniority']:
    unique_categories = df_categorical[i].value_counts()[:20]
    print("Graph for {}\nTotal records = {}".format(i, len(unique_categories)))
    chart = sns.barplot(x=unique_categories.index, y=unique_categories)
    chart.set_xticklabels(chart.get_xticklabels(), rotation=90)
    plt.show()


# In[72]:


df.columns


# In[73]:


pd.pivot_table(df, index=['job_title_simplified','job_seniority'], values='average_salary')


# In[74]:


pd.pivot_table(df, index=['job_state','job_title_simplified'], values='average_salary').sort_values('average_salary', ascending=False)[:20]


# In[75]:


pd.pivot_table(df, index='job_state', values='average_salary').sort_values('average_salary', ascending=False)[:15]


# In[76]:


# Top 15 Industries for Data Scientists
pd.pivot_table(df, index='Industry', values='average_salary').sort_values('average_salary', ascending=False)[:15]


# In[77]:


# Top 10 Sectors for Data Scientists
pd.pivot_table(df, index='Sector', values='average_salary').sort_values('average_salary', ascending=False)[:10]


# In[78]:


# Top Company types that pay Data Scientists well
pd.pivot_table(df, index='Type of ownership', values='average_salary').sort_values('average_salary', ascending=False)[:10]


# In[79]:


# Top 20 Companies that pay Data Scientists well
pd.pivot_table(df, index='Company Name', values='average_salary').sort_values('average_salary', ascending=False)[:20]


# # **Feature Engineering**

# ## *Trimming Columns*

# In[ ]:


# Trimming the 'Industry' column

# Taking top 11 Industries and replacing others by 'Others'
industry_list = ['Biotech & Pharmaceuticals', 'Insurance Carriers', 'Computer Hardware & Software', 'IT Services', 'Health Care Services & Hospitals', 
                 'Enterprise Software & Network Solutions', 'Consulting', 'Internet', 'Advertising & Marketing', 'Aerospace & Defense', 'Consumer Products Manufacturing']

def industry_simplifier(text):
  if text not in industry_list:
    return 'Others'
  else:
    return text

df['Industry'] = df['Industry'].apply(industry_simplifier)


# In[ ]:


# Trimming the 'job_state' column

# Taking top 10 States and replacing others by 'Others'
job_state_list = ['CA', 'MA', 'NY', 'VA', 'IL', 'MD', 'PA', 'TX', 'NC', 'WA']

def job_state_simplifier(text):
  if text not in job_state_list:
    return 'Others'
  else:
    return text

df['job_state'] = df['job_state'].apply(job_state_simplifier)


# In[ ]:


# Adding column of 'job_in_headquarters'
df['job_in_headquarters'] = df.apply(lambda x: 1 if x['Location'] == x['Headquarters'] else 0, axis=1)


# In[83]:


df.columns


# In[ ]:


# Choosing relevant columns
df_model = df.copy(deep=True)
df_model = df_model[['average_salary', 'Rating', 'company_age', 'Size', 'Type of ownership', 'Industry', 'Revenue', 'Competitors',
               'job_title_simplified', 'job_seniority', 'job_state', 'job_in_headquarters', 'python_job', 'spark_job', 'aws_job', 'excel_job', ]]


# In[ ]:


# Renaming columns
df_model.rename(columns={'Rating':'company_rating', 'Size':'company_size', 'Type of ownership':'type_of_ownership',
                         'Industry':'industry', 'Revenue':'revenue', 'Competitors':'competitors'}, inplace=True)


# In[86]:


df_model.columns


# ## *Handling Ordinal Categorical Features*

# In[ ]:


# Mapping ranks to 'company_size' columns since it is ordinal categorical feature
size_map = {'Unknown': 0, '1 to 50 employees': 1, '51 to 200 employees': 2, '201 to 500 employees': 3,
            '501 to 1000 employees': 4, '1001 to 5000 employees': 5, '5001 to 10000 employees': 6, '10000+ employees': 7}

df_model['company_size_rank'] = df_model['company_size'].map(size_map)
df_model.drop('company_size', axis=True, inplace=True)


# In[ ]:


# Mapping ranks to 'revenue	' columns since it is ordinal categorical feature
revenue_map = {'Unknown / Non-Applicable': 0, 'Less than $1 million (USD)': 1, '$1 to $5 million (USD)': 2, '$5 to $10 million (USD)': 3,
            '$10 to $25 million (USD)': 4, '$25 to $50 million (USD)': 5, '$50 to $100 million (USD)': 6, '$100 to $500 million (USD)': 7,
            '$500 million to $1 billion (USD)': 8, '$1 to $2 billion (USD)': 9, '$2 to $5 billion (USD)':10, '$5 to $10 billion (USD)':11, '$10+ billion (USD)':12}

df_model['company_revenue_rank'] = df_model['revenue'].map(revenue_map)
df_model.drop('revenue', axis=True, inplace=True)


# In[ ]:


# Mapping ranks to 'job_seniority	' columns since it is ordinal categorical feature
job_seniority_map = {'na': 0, 'jr': 1, 'senior': 2}

df_model['job_seniority_rank'] = df_model['job_seniority'].map(job_seniority_map)
df_model.drop('job_seniority', axis=True, inplace=True)


# ## *Handling Nominal Categorical Features* 

# In[90]:


# Removing 'type_of_ownership' column using get_dummies()
df_model = pd.get_dummies(columns=['type_of_ownership'], data=df_model)
df_model.shape


# In[91]:


# Removing 'industry' column using get_dummies()
df_model = pd.get_dummies(columns=['industry'], data=df_model)
df_model.shape


# In[92]:


# Removing 'job_title_simplified' column using get_dummies()
df_model = pd.get_dummies(columns=['job_title_simplified'], data=df_model)
df_model.shape


# In[93]:


# Removing 'job_state' column using get_dummies()
df_model = pd.get_dummies(columns=['job_state'], data=df_model)
df_model.shape


# ## *Featuring Scaling* 

# In[94]:


df_model.head()


# In[95]:


# Dataset after Feature Engineering
df_model.shape


# In[ ]:


X = df_model.drop('average_salary', axis=1)
y = df_model['average_salary']


# In[ ]:


from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
columns_to_scale = ['company_rating', 'competitors', 'company_age', 'company_size_rank', 'company_revenue_rank']
X[columns_to_scale] = scaler.fit_transform(X[columns_to_scale])


# In[98]:


# Splitting the dataset into train and test set
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)
print("Training set size: {} and Testing set size: {}".format(X_train.shape, X_test.shape))


# # **Model Building**

# ### *Linear Regression*

# In[ ]:


# Creating linear regression model
from sklearn.linear_model import LinearRegression
lr_model = LinearRegression()


# In[114]:


# Fitting the dataset to the model
lr_model.fit(X_train, y_train)
print("Accuracy of the Linear Regression Model on Training set is : {}% and on Test set is {}%".format(round(lr_model.score(X_train, y_train),4)*100, round(lr_model.score(X_test, y_test),4)*100))


# ### *Decision Tree Regression*

# In[ ]:


# Creating decision tree regression model
from sklearn.tree import DecisionTreeRegressor
decision_model = DecisionTreeRegressor(criterion='mse', max_depth=11, random_state=42)


# In[116]:


# Fitting the dataset to the model
decision_model.fit(X_train, y_train)
print("Accuracy of the Decision Tree Regression Model on Training set is : {}% and on Test set is {}%".format(round(decision_model.score(X_train, y_train),4)*100, round(decision_model.score(X_test, y_test),4)*100))


# ### *Random Forest Regression*

# In[ ]:


# Creating random forest regression model
from sklearn.ensemble import RandomForestRegressor
forest_model = RandomForestRegressor(n_estimators=100, criterion='mse', random_state=42)


# In[118]:


# Fitting the dataset to the model
forest_model.fit(X_train, y_train)
print("Accuracy of the Random Forest Regression Model on Training set is : {}% and on Test set is {}%".format(round(forest_model.score(X_train, y_train),4)*100, round(forest_model.score(X_test, y_test),4)*100))


# ### *AdaBoost Regression Model*

# In[ ]:


# Creating AdaBoost regression model
from sklearn.ensemble import AdaBoostRegressor
adb_model = AdaBoostRegressor(base_estimator=decision_model, n_estimators=250, learning_rate=1, random_state=42)


# In[120]:


# Fitting the dataset to the model
adb_model.fit(X_train, y_train)
print("Accuracy of the AdaBoost Regression Model on Training set is : {}% and on Test set is {}%".format(round(adb_model.score(X_train, y_train),4)*100, round(adb_model.score(X_test, y_test),4)*100))

